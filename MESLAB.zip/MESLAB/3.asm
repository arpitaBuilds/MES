ORG 0000H

MOV R0, #30H     
MOV R1, #40H     
MOV R2, #05H     

LOOP:
MOV A, @R0        
MOV @R1, A        
INC R0            
INC R1            
DJNZ R2, LOOP    
HERE: SJMP HERE   
END