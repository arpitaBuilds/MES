ORG 0000H

START:

    ACALL INIT

    ; Line 1
    MOV A, #080H
    ACALL CMD

    MOV DPTR, #MSG1
    ACALL PRINT

    ; Line 2
    MOV A, #0C0H
    ACALL CMD

    MOV DPTR, #MSG2
    ACALL PRINT

HERE: SJMP HERE

;---------------- INIT ----------------
INIT:
    MOV A, #038H
    ACALL CMD

    MOV A, #0CH
    ACALL CMD

    MOV A, #01H
    ACALL CMD

    ACALL DELAY
    RET

;---------------- COMMAND ----------------
CMD:
    MOV P1, A
    CLR P1.3      ; RS=0
    CLR P1.2      ; EN=0
    ACALL DELAY
    SETB P1.2     ; EN=1
    ACALL DELAY
    CLR P1.2      ; EN=0
    RET

;---------------- DATA ----------------
DATA_SEND:
    MOV P1, A
    SETB P1.3     ; RS=1
    CLR P1.2
    ACALL DELAY
    SETB P1.2
    ACALL DELAY
    CLR P1.2
    RET

;---------------- STRING ----------------
PRINT:
NEXT:
    CLR A
    MOVC A, @A+DPTR
    JZ DONE
    ACALL DATA_SEND
    INC DPTR
    SJMP NEXT

DONE:
    RET

;---------------- DELAY ----------------
DELAY:
    MOV R3, #255
D1: DJNZ R3, D1
    RET

;---------------- DATA ----------------
MSG1: DB 48H, 45H, 4CH, 4CH, 4FH, 00H   ; HELLO
MSG2: DB 4CH, 43H, 44H, 00H             ; LCD
END