ORG 0000H

; -------- LOAD NUMBERS --------
MOV A, #20H        
MOV R1, #10H       
MOV 30H, A        
MOV 31H, R1       
; -------- ADDITION --------
MOV A, 30H
ADD A, 31H
MOV 41H, A        
; -------- SUBTRACTION --------
MOV A, 30H
CLR C              
SUBB A, 31H
MOV 51H, A         
; -------- MULTIPLICATION --------
MOV A, 30H
MOV B, 31H
MUL AB
MOV 60H, A         
MOV 61H, B         

; -------- DIVISION --------
MOV A, 30H
MOV B, 31H
DIV AB
MOV 70H, A        
MOV 71H, B        

HERE: SJMP HERE
END